package sp.senai.br.copiatexto;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etTexto;
    Button btnCopiar;
    TextView tvCopia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etTexto = findViewById(R.id.etTexto);
        btnCopiar = findViewById(R.id.btnCopiar);
        tvCopia = findViewById(R.id.tvCopia);
        tvCopia.setText(null);
    }

    public void copiar(View c){
        //Pega o texto do EditText e armazena na variável
        String sTexto = etTexto.getText().toString();
        //Insere o TextVier o conteúdo da variável
        tvCopia.setText(sTexto);
        //Limpa o EditText
        etTexto.setText(null);
        //coloca o cursor de digitação de volta no EditText
        etTexto.requestFocus();
    }
}